# Functions for the inventory forecasting project: a simulator with KNOWN demand distributions,
# cleaning, probabilistic demand forecasts, newsvendor order quantities and cost evaluation.

library(dplyr)
library(tibble)

N_TRAIN <- 130   # weeks used for fitting; the remaining weeks are the test period

#' Simulate weekly demand for many SKUs: negative-binomial counts whose mean has a trend, yearly seasonality and
#' a promotion lift. SKUs differ widely in volume (some sell a few units a week, some dozens), in noise,
#' and in the economics of a stock-out (margin) versus an overstock (holding + write-off).
simulate_inventory <- function(n_sku = 40, n_weeks = 156, seed = 1, messy = TRUE) {
  set.seed(seed)
  t <- seq_len(n_weeks)
  sku <- sprintf("SKU%03d", seq_len(n_sku))
  base <- exp(runif(n_sku, log(0.4), log(60))); trend <- rnorm(n_sku, 0.002, 0.004)
  amp <- runif(n_sku, 0.1, 0.6); phase <- runif(n_sku, 0, 2 * pi); size <- runif(n_sku, 1.5, 15)
  price <- runif(n_sku, 8, 40); cost <- price * runif(n_sku, 0.4, 0.75)
  holding <- cost * runif(n_sku, 0.05, 0.2)
  skus <- tibble(sku = sku, unit_price = round(price, 2), unit_cost = round(cost, 2), holding_cost = round(holding, 2))

  promo <- matrix(rbinom(n_sku * n_weeks, 1, 0.12), n_sku, n_weeks)
  mu <- sapply(t, function(w) base * exp(trend * w + amp * sin(2 * pi * w / 52 + phase) + 0.5 * promo[, w]))
  demand <- matrix(rnbinom(n_sku * n_weeks, size = rep(size, n_weeks), mu = as.vector(mu)), n_sku, n_weeks)

  weeks <- as.Date("2022-01-03") + 7 * (t - 1)
  raw <- tibble(sku = rep(sku, times = n_weeks), week_start = rep(weeks, each = n_sku),
                units = as.vector(demand), promo = ifelse(as.vector(promo) == 1, "Y", "N"))
  truth <- tibble(sku = rep(sku, times = n_weeks), week_start = rep(weeks, each = n_sku),
                  mu = as.vector(mu), size = rep(size, times = n_weeks))
  if (messy) {
    n <- nrow(raw)
    raw$units[sample(n, round(0.01 * n))] <- NA                              # missing sales records
    raw$units[sample(n, 20)] <- -1                                           # returns booked as negative sales
    raw$promo[sample(n, 100)] <- "yes"                                       # inconsistent promo flag
    raw$sku[sample(n, 80)] <- tolower(raw$sku[sample(n, 80)])                # inconsistent SKU labels
    raw <- bind_rows(raw, raw[sample(n, 60), ])                              # duplicated rows
  }
  list(raw = raw, skus = skus, truth = truth)
}

#' Clean: standardise labels, remove duplicates, negative units set to 0, missing units filled with the
#' median of the same SKU's four nearest weeks.
clean_inventory <- function(raw) {
  n0 <- nrow(raw)
  x <- raw |> mutate(sku = toupper(trimws(sku)), promo = as.integer(toupper(trimws(promo)) %in% c("Y", "YES", "1")))
  x <- distinct(x, sku, week_start, .keep_all = TRUE) |> arrange(sku, week_start)
  n_dup <- n0 - nrow(x)
  n_neg <- sum(x$units < 0, na.rm = TRUE); x$units[!is.na(x$units) & x$units < 0] <- 0
  n_na <- sum(is.na(x$units))
  x <- x |> group_by(sku) |> mutate(
    units = {
      u <- units; na_i <- which(is.na(u))
      for (i in na_i) { nb <- u[setdiff(max(1, i - 2):min(length(u), i + 2), i)]; u[i] <- round(median(nb, na.rm = TRUE)) }
      u }, week = row_number()) |> ungroup()
  log <- tibble(step = c("Rows received", "Duplicate SKU-weeks removed", "Negative units set to 0", "Missing units filled", "SKU-weeks analysed"),
                rows = c(n0, n_dup, n_neg, n_na, nrow(x)))
  list(data = x, log = log)
}

#' Demand pattern classification (Syntetos-Boylan): ADI = average gap between demands, CV2 = squared
#' coefficient of variation of non-zero demand sizes.
classify_demand <- function(u) {
  nz <- u[u > 0]; adi <- length(u) / max(length(nz), 1)
  cv2 <- if (length(nz) > 1) (sd(nz) / mean(nz))^2 else NA_real_
  cls <- ifelse(adi < 1.32 & cv2 < 0.49, "Smooth", ifelse(adi < 1.32, "Erratic", ifelse(cv2 < 0.49, "Intermittent", "Lumpy")))
  list(adi = adi, cv2 = cv2, class = cls)
}

# ---- Forecasting models ----------------------------------------------------------
design_matrix <- function(week, promo) {
  cbind(1, week / 156, sin(2 * pi * week / 52), cos(2 * pi * week / 52), sin(4 * pi * week / 52), cos(4 * pi * week / 52), promo)
}

#' Poisson regression (log link) on trend, two seasonal harmonics and promotion, with a negative-binomial
#' size estimated by the method of moments from the Pearson residuals.
fit_demand <- function(week, promo, units) {
  X <- design_matrix(week, promo)
  b <- suppressWarnings(glm.fit(X, units, family = poisson(), control = list(maxit = 50)))$coefficients
  b[is.na(b)] <- 0
  mu <- as.vector(exp(pmin(X %*% b, 20)))
  excess <- sum((units - mu)^2 - mu)
  size <- if (excess <= 0) 1e3 else max(sum(mu^2) / excess, 0.3)
  list(beta = b, size = size)
}
predict_mean <- function(fit, week, promo) as.vector(exp(pmin(design_matrix(week, promo) %*% fit$beta, 20)))

#' Croston's method with the Syntetos-Boylan bias correction: smooths demand size and the gap between demands.
croston_sba <- function(u, alpha = 0.1) {
  nz <- which(u > 0)
  if (length(nz) < 2) return(mean(u))
  z <- u[nz[1]]; p <- nz[1]; last <- nz[1]
  for (j in nz[-1]) { z <- z + alpha * (u[j] - z); p <- p + alpha * ((j - last) - p); last <- j }
  (1 - alpha / 2) * z / p
}

# ---- Decisions and costs ------------------------------------------------------------
#' Newsvendor: with underage cost cu (lost margin per unit short) and overage cost co (per unit left over),
#' expected cost is minimised by ordering the demand quantile at the critical ratio cu / (cu + co).
critical_ratio <- function(cu, co) cu / (cu + co)

cost_of_order <- function(q, d, cu, co) cu * pmax(d - q, 0) + co * pmax(q - d, 0)

#' Exact expected cost of ordering q when demand is negative binomial with the TRUE mean and size.
expected_cost_true <- function(q, mu, size, cu, co) {
  top <- ceiling(mu + 12 * sqrt(mu + mu^2 / size) + 20)
  x <- 0:top; p <- dnbinom(x, size = size, mu = mu)
  sum(p * cost_of_order(q, x, cu, co))
}

pinball <- function(q, d, tau) ifelse(d >= q, tau * (d - q), (1 - tau) * (q - d))
