source("R/inventory_functions.R")
library(tidyr)
set.seed(1)

raw <- read.csv("data/raw/weekly_sales.csv", stringsAsFactors = FALSE); raw$week_start <- as.Date(raw$week_start)
skus <- read.csv("data/raw/sku_economics.csv", stringsAsFactors = FALSE)
cleaned <- clean_inventory(raw); d <- cleaned$data
print(cleaned$log)
stopifnot(nrow(d) == 40 * 156, !anyNA(d$units), all(d$units >= 0))

# ---- SKU profile and demand pattern (training period only) -------------------------------
train <- d |> filter(week <= N_TRAIN)
profile <- train |> group_by(sku) |> summarise(mean_units = mean(units), zero_share = mean(units == 0),
  adi = classify_demand(units)$adi, cv2 = classify_demand(units)$cv2, demand_class = classify_demand(units)$class, .groups = "drop") |>
  left_join(skus, by = "sku") |>
  mutate(underage_cost = unit_price - unit_cost, overage_cost = holding_cost + 0.15 * unit_cost,
         critical_ratio = critical_ratio(underage_cost, overage_cost))
print(count(profile, demand_class))
print(summary(profile$critical_ratio))

# ---- Promotion lift and seasonality ----------------------------------------------------------
promo_lift <- train |> group_by(sku) |> summarise(lift = mean(units[promo == 1]) / mean(units[promo == 0]), .groups = "drop")
cat("Median promo lift across SKUs:", round(median(promo_lift$lift, na.rm = TRUE), 2), "\n")
total_weekly <- d |> group_by(week_start) |> summarise(units = sum(units), .groups = "drop")

saveRDS(list(data = d, log = cleaned$log, profile = profile, promo_lift = promo_lift, total_weekly = total_weekly),
        "data/clean/inventory_clean.rds")
