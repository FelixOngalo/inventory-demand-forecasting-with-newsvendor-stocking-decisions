source("R/inventory_functions.R")
library(tidyr)
set.seed(3)

res <- readRDS("data/clean/forecast_results.rds"); long <- res$long; fc <- res$fc

# ---- 1. Does a flat service level work? Sweep a single service level for all SKUs -----------------
taus <- c(0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.98, 0.99)
sweep <- bind_rows(lapply(taus, function(tau) {
  q <- qnbinom(tau, size = fc$size_hat, mu = fc$mu_hat)
  tibble(tau = tau, expected_cost = mean(mapply(expected_cost_true, q, fc$mu_true, fc$size_true, fc$underage_cost, fc$overage_cost)),
         fill_rate = sum(pmin(fc$demand, q)) / sum(fc$demand))
}))
cost_based <- res$summary_tbl |> filter(policy == "nbreg")
cat("Best flat service level:", sweep$tau[which.min(sweep$expected_cost)], "cost", round(min(sweep$expected_cost), 2),
    "| cost-based per-SKU quantile cost", round(cost_based$expected_cost_per_sku_week, 2), "\n")
print(sweep)

# ---- 2. Where does the saving come from? Cost by demand class and policy -----------------------------
by_class <- long |> filter(policy %in% c("rule", "nbreg", "oracle")) |> group_by(demand_class, policy) |>
  summarise(expected_cost = mean(expected_cost), .groups = "drop") |> pivot_wider(names_from = policy, values_from = expected_cost) |>
  mutate(rule_excess = rule / oracle - 1, nbreg_excess = nbreg / oracle - 1)
print(by_class)

# ---- 3. Bootstrap over SKUs: saving of the forecasting model over the rule of thumb --------------------
skus <- unique(long$sku); B <- 500
per_sku <- long |> filter(policy %in% c("rule", "nbreg", "oracle")) |> group_by(sku, policy) |>
  summarise(cost = sum(expected_cost), .groups = "drop") |> pivot_wider(names_from = policy, values_from = cost)
boot <- bind_rows(lapply(seq_len(B), function(b) {
  s <- per_sku[sample(nrow(per_sku), replace = TRUE), ]
  tibble(rep = b, saving_vs_rule = 1 - sum(s$nbreg) / sum(s$rule), excess_vs_oracle = sum(s$nbreg) / sum(s$oracle) - 1)
}))
boot_summary <- boot |> pivot_longer(-rep, names_to = "quantity", values_to = "value") |> group_by(quantity) |>
  summarise(mean = mean(value), lower = quantile(value, 0.025), upper = quantile(value, 0.975), .groups = "drop")
print(boot_summary)

# ---- 4. Annual value: cost saved per SKU-year ------------------------------------------------------------
value <- res$summary_tbl |> select(policy_label, expected_cost_per_sku_week) |>
  mutate(cost_per_sku_year = 52 * expected_cost_per_sku_week, saving_vs_rule_per_sku_year = cost_per_sku_year[policy_label == res$policy_names[["rule"]]] - cost_per_sku_year)
print(value)

saveRDS(list(sweep = sweep, by_class = by_class, boot_summary = boot_summary, value = value, B = B), "data/clean/decision_results.rds")
